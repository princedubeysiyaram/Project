package com.example.onlineexam.Adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.onlineexam.R;
import com.example.onlineexam.models.RankModel;

import java.util.List;

public class RankAdapter extends RecyclerView.Adapter<RankAdapter.viewHolder> {
    private List<RankModel> uerList;

    public RankAdapter(List<RankModel> uerList) {
        this.uerList = uerList;
    }

    @NonNull
    @Override
    public RankAdapter.viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rank_item_layout, parent, false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RankAdapter.viewHolder holder, int position) {
        String name = uerList.get(position).getName();
        int score = uerList.get(position).getScore();
        int rank = uerList.get(position).getRank();
        holder.setData(name, score, rank);
    }

    @Override
    public int getItemCount() {
        if (uerList.size() > 10) {
            return 10;
        } else {
            return uerList.size();
        }

    }

    public class viewHolder extends RecyclerView.ViewHolder {
        private TextView nameTV, rankTV, scoreTV, imgTV;

        public viewHolder(@NonNull View itemView) {
            super(itemView);
            nameTV = itemView.findViewById(R.id.name);
            rankTV = itemView.findViewById(R.id.rank);
            scoreTV = itemView.findViewById(R.id.score);
            imgTV = itemView.findViewById(R.id.img_text);
        }

        private void setData(String name, int score, int rank) {
            nameTV.setText(name);
            scoreTV.setText("Score :" + score);
            rankTV.setText("Rank :" + rank);
            imgTV.setText(name.toUpperCase().substring(0, 1));
        }
    }
}
