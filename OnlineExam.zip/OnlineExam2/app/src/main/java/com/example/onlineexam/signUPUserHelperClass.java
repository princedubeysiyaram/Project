package com.example.onlineexam;

public class signUPUserHelperClass {
 String name,email,passW,confPass;

 public signUPUserHelperClass() {
 }

 public signUPUserHelperClass(String name, String email, String passW, String confPass) {
  this.name = name;
  this.email = email;
  this.passW = passW;
  this.confPass = confPass;
 }

 public String getName() {
  return name;
 }

 public void setName(String name) {
  this.name = name;
 }

 public String getEmail() {
  return email;
 }

 public void setEmail(String email) {
  this.email = email;
 }

 public String getPassW() {
  return passW;
 }

 public void setPassW(String passW) {
  this.passW = passW;
 }

 public String getConfPass() {
  return confPass;
 }

 public void setConfPass(String confPass) {
  this.confPass = confPass;
 }
}
