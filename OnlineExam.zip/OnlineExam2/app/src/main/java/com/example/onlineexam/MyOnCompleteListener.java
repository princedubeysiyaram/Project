package com.example.onlineexam;

public interface MyOnCompleteListener {
    void OnSuccess();
    void onFailure();
}
