package com.example.onlineexam.models;

public class TestModel {
    private String testID;
    private int topScore;
    private int time;

    public TestModel(String testID, int topScore, int time) {
        this.testID = testID;
        this.topScore = topScore;
        this.time = time;
    }

    public String getTestID() {
        return testID;
    }

    public void setTestID(String testID) {
        this.testID = testID;
    }

    public int getTopScore() {
        return topScore;
    }

    public void setTopScore(int topScore) {
        this.topScore = topScore;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }
}



//    String name_ = name.getText().toString().trim();
//    String email_ = email.getText().toString().trim();
//    String pass_ = pass.getText().toString().trim();
//    String confrimpass_ = confirmPass.getText().toString().trim();
//                if (!name_.isEmpty()) {
//                        name.setError(null);
//                        name.requestFocus();
//                        if (!email_.isEmpty()) {
//                        email.setError(null);
//                        email.requestFocus();
//                        if (email_.matches("^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$")) {
//                        email.setError(null);
//                        email.requestFocus();
//                        if (!pass_.isEmpty()) {
//                        pass.setError(null);
//                        pass.requestFocus();
//                        if (!confrimpass_.isEmpty()) {
//                        confirmPass.setError(null);
//                        confirmPass.requestFocus();
//                        if(pass_.compareTo(confrimpass_)!=0){
//                        Toast.makeText(SighupActivity.this,"Please Enter same Password",Toast.LENGTH_SHORT).show();
//                        }
//                        ProgressDialog.show();
//                        firebaseDatabase = FirebaseDatabase.getInstance();
//                        reference=firebaseDatabase.getReference("data");
//
//                        //Get All value
//                        String name_s= name.getText().toString().trim();
//                        String email_s = email.getText().toString().trim();
//                        String pass_s = pass.getText().toString().trim();
//                        String confrimpass_s = confirmPass.getText().toString().trim();
//                        signUPUserHelperClass signUPUserHelperClasss = new signUPUserHelperClass(name_s,email_s,pass_s,confrimpass_s);
//                        reference.child(name_s).setValue(signUPUserHelperClasss);
//                        Toast.makeText(getApplicationContext(),"Registration successfully complete",Toast.LENGTH_SHORT).show();
//                        Intent intent = new Intent(getApplicationContext(),loginActivity.class);
//        startActivity(intent);
//        finish();
//
//
//
//
//
//
//        } else {
//        confirmPass.setError("Please Enter Password");
//        }
//        } else {
//        pass.setError("Please Enter Password");
//        }
//        }else{
//        email.setError("Please Enter Valid Email ID ");
//        }
//        } else {
//        email.setError("Please Enter Email ID");
//        }
//
//
//        } else {
//        name.setError("Please Enter your name ");
//        }
//
//
//        }
//        });
