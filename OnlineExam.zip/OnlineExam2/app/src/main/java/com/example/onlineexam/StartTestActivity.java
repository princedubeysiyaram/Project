package com.example.onlineexam;

import static com.example.onlineexam.DbQuery.g_catList;
import static com.example.onlineexam.DbQuery.loadquestions;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.protobuf.StringValue;

public class StartTestActivity extends AppCompatActivity {
private TextView catName,testNo,totalQ,bestScore,time;
private Button startTestB;
private ImageView backB;
private Dialog ProgressDialog;
private TextView dialogText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_test);


        init();
        ProgressDialog = new Dialog(StartTestActivity.this);
        ProgressDialog.setContentView(R.layout.dialog_layout);
        ProgressDialog.setCancelable(false);
        ProgressDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialogText = ProgressDialog.findViewById(R.id.dialogtext);
        dialogText.setText("Loading..");
        ProgressDialog.show();
        loadquestions(new MyCompleteListener() {
            @Override
            public void onSuccess() {
                setData();
                ProgressDialog.dismiss();
            }

            @Override
            public void onFailure() {
                ProgressDialog.dismiss();
                Toast.makeText(StartTestActivity.this,"Something went wrong ! pls try again",Toast.LENGTH_SHORT).show();

            }
        });
    }
    private void init()
    {
        catName = findViewById(R.id.st_cat_name);
        testNo = findViewById(R.id.st_test_no);
        totalQ = findViewById(R.id.st_total_ques);
        bestScore = findViewById(R.id.st_best_score);
        time = findViewById(R.id.st_time);
        startTestB = findViewById(R.id.start_testB);
        backB = findViewById(R.id.st_back);
        backB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StartTestActivity.this.finish();
            }
        });
        startTestB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StartTestActivity.this,QuestionActivity.class);
                startActivity(intent);
                finish();
            }
        });


    }
    private void setData()
    {
        catName.setText(g_catList.get(DbQuery.g_selected_cat_index).getName());
        testNo.setText("Test No. "+ String.valueOf(DbQuery.g_selected_test_index + 1));
        totalQ.setText(String.valueOf(DbQuery.g_quesList.size()));
        bestScore.setText(String.valueOf(DbQuery.g_testList.get(DbQuery.g_selected_test_index).getTopScore()));
        time.setText(String.valueOf(DbQuery.g_testList.get(DbQuery.g_selected_test_index).getTime()));
    }
}