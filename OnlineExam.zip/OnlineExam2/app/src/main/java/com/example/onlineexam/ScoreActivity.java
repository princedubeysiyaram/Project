package com.example.onlineexam;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.TimeUnit;

public class ScoreActivity extends AppCompatActivity {
    private TextView scoreTv,timeTv,totalQTV,correctQTV,wrongQTV,unattemptQTV;
    Button leaderB,reAttemptB,viewAnsB;
    private  long timeTaken;
    private Dialog ProgressDialog;
    private TextView dialogText;
    private int finalScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //int cat_index = getIntent().getIntExtra("CAT_INDEX",0);
        getSupportActionBar().setTitle("Result");
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        ProgressDialog = new Dialog(ScoreActivity.this);
        ProgressDialog.setContentView(R.layout.dialog_layout);
        ProgressDialog.setCancelable(false);
        ProgressDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialogText = ProgressDialog.findViewById(R.id.dialogtext);
        dialogText.setText("Loading..");
        ProgressDialog.show();

        init();
        loadData();
        viewAnsB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        reAttemptB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                reAttempt();
            }
        });
        saveResult();
    }
    private void init()
    {
        scoreTv = findViewById(R.id.score);
        timeTv = findViewById(R.id.time);
        totalQTV = findViewById(R.id.totalQ);
        correctQTV = findViewById(R.id.correctQ);
        wrongQTV = findViewById(R.id.wrongQ);
        unattemptQTV = findViewById(R.id.un_attempt);
        leaderB = findViewById(R.id.leaderB);
        reAttemptB = findViewById(R.id.reattemptB);
        viewAnsB = findViewById(R.id.view_answerB);

    }
    private void loadData()
    {
        int correctQ = 0,wrongQ=0,unattemptQ = 0;
        for (int i=0;i<DbQuery.g_quesList.size();i++)
        {
            if(DbQuery.g_quesList.get(i).getSelectedAns()== -1)
            {
                unattemptQ ++;
            }
            else
            {
                if (DbQuery.g_quesList.get(i).getSelectedAns()==DbQuery.g_quesList.get(i).getCorrectAns() )
                {
                    correctQ++;
                }
                else
                {
                    wrongQ++;
                }
            }
        }
        correctQTV.setText(String.valueOf(correctQ));
        wrongQTV.setText(String.valueOf(wrongQ));
        unattemptQTV.setText(String.valueOf(unattemptQ));
        totalQTV.setText(String.valueOf(DbQuery.g_quesList.size()));
        finalScore = (correctQ*100)/DbQuery.g_quesList.size();
        scoreTv.setText(String.valueOf(finalScore));

        timeTaken = getIntent().getLongExtra("TIME_TAKEN",0);
        String time = String.format("%02d:%02d min",
                TimeUnit.MILLISECONDS.toMinutes(timeTaken),
                TimeUnit.MILLISECONDS.toSeconds(timeTaken) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(timeTaken))
        );
        timeTv.setText(time);

    }
    private void reAttempt()
    {
        for (int i =0;i<DbQuery.g_quesList.size();i++)
        {
            DbQuery.g_quesList.get(i).setSelectedAns(-i);
            DbQuery.g_quesList.get(i).setStatus(DbQuery.NOT_VISITED);
        }
        Intent intent = new Intent(ScoreActivity.this,StartTestActivity.class);
        startActivity(intent);
        finish();
    }
private  void  saveResult()
{
DbQuery.saveResult(finalScore, new MyCompleteListener() {
    @Override
    public void onSuccess() {
        ProgressDialog.dismiss();
    }

    @Override
    public void onFailure() {
        Toast.makeText(ScoreActivity.this,"Something went wrong ! pls try again",Toast.LENGTH_SHORT).show();
        ProgressDialog.dismiss();
    }
});
}
    @Override
    public  boolean onOptionsItemSelected(@NonNull MenuItem item){
        if(item.getItemId()== android.R.id.home){
            ScoreActivity.this.finish();
        }
        return super.onOptionsItemSelected(item);
    }

}
































