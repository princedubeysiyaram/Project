package com.example.onlineexam;

public interface MyCompleteListener {
    void  onSuccess();
    void  onFailure();
}
