package com.example.onlineexam;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


import android.app.Dialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MyProfileActivity extends AppCompatActivity {
private EditText name,email,phone;
private LinearLayout editB;
private Button cancelB,saveB;
private TextView profileText;
private LinearLayout button_layout;
private String nameStr,phoneNoStr;
private Dialog ProgressDialog;
private TextView dialogText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_profile);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("My profile");
        getSupportActionBar().setDisplayShowTitleEnabled(true);

        name = findViewById(R.id.mp_name);
        email =findViewById(R.id.mp_email);
        phone = findViewById(R.id.mp_phone);
        profileText = findViewById(R.id.profile_text);
        editB = findViewById(R.id.editB);
        cancelB = findViewById(R.id.cancelB);
        saveB = findViewById(R.id.saveB);
        button_layout = findViewById(R.id.button_layout);
        ProgressDialog = new Dialog(MyProfileActivity.this);
        ProgressDialog.setContentView(R.layout.dialog_layout);
        ProgressDialog.setCancelable(false);
        ProgressDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialogText = ProgressDialog.findViewById(R.id.dialogtext);
        dialogText.setText("Updating Data...");
        disableEditing();
        editB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enableEditing();
            }
        });
        cancelB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                disableEditing();
            }
        });
        saveB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validate())
                {
                    saveData();
                }
            }
        });

    }
    private void disableEditing()
    {
        name.setEnabled(false);
        email.setEnabled(false);
        phone.setEnabled(false);
        button_layout.setVisibility(View.GONE);
        name.setText(DbQuery.myProfile.getName());
        email.setText(DbQuery.myProfile.getEmail());
        if (DbQuery.myProfile.getPhone()!=null)
            phone.setText(DbQuery.myProfile.getPhone());
        String profileName = DbQuery.myProfile.getName();
        profileText.setText(profileName.toUpperCase().substring(0,1));
    }
    private void enableEditing()
    {
        name.setEnabled(true);
        //email.setEnabled(false);
        phone.setEnabled(true);
        button_layout.setVisibility(View.VISIBLE);
    }
    private boolean validate()
    {
      nameStr = name.getText().toString();
      phoneNoStr = phone.getText().toString();
      if(nameStr.isEmpty())
      {
          name.setError("Name can not be empty!");
          return false;
      }
      if (!phoneNoStr.isEmpty())
      {
         if (!((phoneNoStr.length()==10)&& (TextUtils.isDigitsOnly(phoneNoStr))))
         {
             phone.setError("Enter Valid Phone number !");
             return  false;
         }
      }
      return true;
    }
    private void saveData()
    {
        ProgressDialog.show();
        if (phoneNoStr.isEmpty())
            phoneNoStr=null;
        DbQuery.saveProfileData(nameStr, phoneNoStr, new MyCompleteListener() {
            @Override
            public void onSuccess() {
                Toast.makeText(MyProfileActivity.this,"Profile Updated Successfully.",Toast.LENGTH_SHORT).show();
                disableEditing();
                ProgressDialog.dismiss();
            }

            @Override
            public void onFailure() {
                Toast.makeText(MyProfileActivity.this,"Something went wrong try again letter?",Toast.LENGTH_SHORT).show();
                ProgressDialog.dismiss();
            }
        });
    }

    @Override
    public  boolean onOptionsItemSelected(@NonNull MenuItem item){
        if(item.getItemId()== android.R.id.home){
            MyProfileActivity.this.finish();
        }
        return super.onOptionsItemSelected(item);
    }



}