package com.example.onlineexam;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class SplashActivity extends AppCompatActivity {
private  TextView appName;
private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        appName = findViewById(R.id.app_name);
        Typeface typeface = ResourcesCompat.getFont(this,R.font.blacklist);
        appName.setTypeface(typeface);
        Animation anim = AnimationUtils.loadAnimation(this,R.anim.myanim);
        appName.setAnimation(anim);
        mAuth = FirebaseAuth.getInstance();
        DbQuery.g_firestors = FirebaseFirestore.getInstance();
        new Thread(){
            @Override
            public void run()
            {
                try {
                    sleep(3000);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
                if (mAuth.getCurrentUser()!=null)
                {
                    DbQuery.loadData(new MyCompleteListener() {
                        @Override
                        public void onSuccess() {
                            Intent intent = new Intent(SplashActivity.this,MainActivity.class);
                            startActivity(intent);
                            SplashActivity.this.finish();
                        }

                        @Override
                        public void onFailure() {

                            Toast.makeText(SplashActivity.this,"Something went wrong! Pls try again", Toast.LENGTH_SHORT).show();

                        }
                    });



                }else
                {
                    Intent intent = new Intent(SplashActivity.this,loginActivity.class);
                    startActivity(intent);
                    SplashActivity.this.finish();
                }

            }
        }.start();

    }
}




//    String email_ = name.getText().toString().trim();
//    String pass_ = Password.getText().toString().trim();
//                if (!email_.isEmpty()) {
//                        name.setError(null);
//                        name.requestFocus();
//                        if (!pass_.isEmpty()) {
//                        Password.setError(null);
//                        Password.requestFocus();
//                        ProgressDialog.show();
//final String username_data = name.getText().toString().trim();
//final  String password_data= Password.getText().toString().trim();
//        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
//        DatabaseReference databaseReference = firebaseDatabase.getReference("data");
//        Query check_username = databaseReference.orderByChild("name").equalTo(username_data);
//        check_username.addListenerForSingleValueEvent(new ValueEventListener() {
//@Override
//public void onDataChange(@NonNull DataSnapshot snapshot) {
//        ProgressDialog.dismiss();
//        if (snapshot.exists()){
//        name.setError(null);
//        name.requestFocus();
//        String passwordCheck = snapshot.child(username_data).child("passW").getValue(String.class);
//        if(passwordCheck.equals(password_data)){
//        Password.setError(null);
//        Password.requestFocus();
//        Toast.makeText(getApplicationContext(),"Login Successfully done ",Toast.LENGTH_SHORT).show();
//        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
//        startActivity(intent);
//        finish();
//
//        }else{
//        Password.setError("wrong password");
//        }
//        }else{
//        name.setError("user does not exist");
//        }
//        }
//
//@Override
//public void onCancelled(@NonNull DatabaseError error) {
//
//        }
//        });
//        } else {
//        Password.setError("Enter Password");
//        }
//        } else {
//        name.setError("Enter Email-ID");
//        }
//
//
//        }
//        });