package com.example.onlineexam;

import static android.os.Build.VERSION_CODES.O;
import static android.os.Build.VERSION_CODES.P;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SighupActivity extends AppCompatActivity {
    private EditText name, email, pass, confirmPass;
    private Button sighUpB;
    private ImageView backB;
    //    FirebaseDatabase firebaseDatabase;
//    DatabaseReference reference;
    private Dialog ProgressDialog;
    private TextView dialogText;
    FirebaseAuth mAuth;
    String emailStr, passStr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sighup);
        name = findViewById(R.id.Username);
        email = findViewById(R.id.emailID);
        pass = findViewById(R.id.Passwords);
        confirmPass = findViewById(R.id.confirm_pass);
        sighUpB = findViewById(R.id.signupB);
        backB = findViewById(R.id.backB);
        mAuth = FirebaseAuth.getInstance();
        ProgressDialog = new Dialog(SighupActivity.this);
        ProgressDialog.setContentView(R.layout.dialog_layout);
        ProgressDialog.setCancelable(false);
        ProgressDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialogText = ProgressDialog.findViewById(R.id.dialogtext);
        dialogText.setText("Registering user..");
        backB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        sighUpB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                validate();


            }
        });
    }

    private void validate() {
        String nameStr = name.getText().toString().trim();
        String passStr = pass.getText().toString().trim();
        String emailStr = email.getText().toString().trim();
        String confirmPassStr = confirmPass.getText().toString().trim();
        if (TextUtils.isEmpty(nameStr)) {
            name.setError("Name can not be Empty");
            name.requestFocus();
        } else if (TextUtils.isEmpty(passStr)) {
            pass.setError("password can not be Empty");
            pass.requestFocus();
        } else if (TextUtils.isEmpty(emailStr)) {
            email.setError("email can not be empty");
            email.requestFocus();

        }else if(TextUtils.isEmpty(confirmPassStr)){
            confirmPass.setError("password can not be empty ");
            confirmPass.requestFocus();
        }else if (passStr.compareTo(confirmPassStr)!=0) {
            Toast.makeText(SighupActivity.this,"Both password Should be same",Toast.LENGTH_SHORT).show();
        }else{
            ProgressDialog.show();
            mAuth.createUserWithEmailAndPassword(emailStr,passStr).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        Toast.makeText(SighupActivity.this,"user register successfully",Toast.LENGTH_SHORT).show();
                        DbQuery.createUserData(emailStr,nameStr, new MyCompleteListener() {
                            @Override
                            public void onSuccess() {
                                DbQuery.loadCategories(new MyCompleteListener() {
                                    @Override
                                    public void onSuccess() {
                                        DbQuery.loadData(new MyCompleteListener() {
                                            @Override
                                            public void onSuccess() {
                                                ProgressDialog.dismiss();
                                                //startActivity(new Intent(SighupActivity.this,MainActivity.class));
                                                Intent intent= new Intent(SighupActivity.this,MainActivity.class);
                                                startActivity(intent);
                                                SighupActivity.this.finish();
                                            }

                                            @Override
                                            public void onFailure() {
                                                ProgressDialog.dismiss();
                                                Toast.makeText(SighupActivity.this,"Something went wrong! Pls try again", Toast.LENGTH_SHORT).show();

                                            }
                                        });

                                    }

                                    @Override
                                    public void onFailure() {
                                        Toast.makeText(SighupActivity.this,"Something went wrong ! pls try again",Toast.LENGTH_SHORT).show();
                                        ProgressDialog.dismiss();
                                    }
                                });

                            }

                            @Override
                            public void onFailure() {
                                Toast.makeText(SighupActivity.this,"Something went wrong ! pls try again",Toast.LENGTH_SHORT).show();
                              ProgressDialog.dismiss();
                            }
                        });


                    }else{
                        ProgressDialog.dismiss();
                        Toast.makeText(SighupActivity.this,"Registration Error"+task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                    }

                }
            });
        }

    }

}






