package com.example.onlineexam;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GithubAuthProvider;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class loginActivity extends AppCompatActivity {
    private EditText email, Password;
    private Button loginB;
    private TextView forgotPassB, signupB;
    private Dialog ProgressDialog;
    private TextView dialogText;
    private FirebaseAuth mAuth;
    private RelativeLayout gSignB;
    private GoogleSignInClient mGoogleSignInClient;
    private int RC_SIGN_IN = 104;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email = findViewById(R.id.email);
        Password = findViewById(R.id.Password);
        loginB = findViewById(R.id.loginB);
        forgotPassB = findViewById(R.id.forget_password);
        signupB = findViewById(R.id.signupB);
        gSignB = findViewById(R.id.g_signB);


        mAuth = FirebaseAuth.getInstance();
        ProgressDialog = new Dialog(loginActivity.this);
        ProgressDialog.setContentView(R.layout.dialog_layout);
        ProgressDialog.setCancelable(false);
        ProgressDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialogText = ProgressDialog.findViewById(R.id.dialogtext);
        dialogText.setText("Registering user..");
        //configure Google sign in
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        gSignB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                googleSignIn();
            }
        });

        loginB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validateData()) {
                    login();
                }

            }
        });


        signupB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(loginActivity.this, SighupActivity.class);
                startActivity(intent);
            }
        });


    }

    private boolean validateData() {
        boolean status = false;
        if (email.getText().toString().isEmpty()) {
            email.setError("Enter email id");
            return false;
        }
        if (Password.getText().toString().isEmpty()) {
            Password.setError("Enter password");
            return false;
        }
        return true;
    }

    private void login() {
        ProgressDialog.show();
        mAuth.signInWithEmailAndPassword(email.getText().toString().trim(), Password.getText().toString().trim())
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Toast.makeText(loginActivity.this, "Login Success ", Toast.LENGTH_SHORT).show();
                            DbQuery.loadData(new MyCompleteListener() {
                                @Override
                                public void onSuccess() {
                                    ProgressDialog.dismiss();
                                    Intent intent = new Intent(loginActivity.this, MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                }

                                @Override
                                public void onFailure() {
                                    Toast.makeText(loginActivity.this,"Something went wrong ! pls try again",Toast.LENGTH_SHORT).show();
                                    ProgressDialog.dismiss();
                                }
                            });



                        } else {
                            ProgressDialog.dismiss();
                            Toast.makeText(loginActivity.this, task.getException().getMessage(),
                                    Toast.LENGTH_SHORT).show();

                        }
                    }
                });
    }

    private void googleSignIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(resultCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                firebaseAuthWithGoogle(account.getIdToken());

            } catch (ApiException e) {
                Toast.makeText(loginActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();

            }
        }
    }

    private void firebaseAuthWithGoogle(String idToken){
       ProgressDialog.show();
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
       mAuth.signInWithCredential(credential)
              .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                          @Override
                          public void onComplete(@NonNull Task<AuthResult> task) {
                              if (task.isSuccessful()) {
                                  Toast.makeText(loginActivity.this, "Google Sign In Success", Toast.LENGTH_SHORT).show();
                                  FirebaseUser user = mAuth.getCurrentUser();
                                  if (task.getResult().getAdditionalUserInfo().isNewUser())
                                  {
                                      DbQuery.createUserData(user.getEmail(), user.getDisplayName(), new MyCompleteListener() {
                                          @Override
                                          public void onSuccess() {
                                              DbQuery.loadData(new MyCompleteListener() {
                                                  @Override
                                                  public void onSuccess() {
                                                      ProgressDialog.dismiss();
                                                      Intent intent = new Intent(loginActivity.this, MainActivity.class);
                                                      startActivity(intent);
                                                      loginActivity.this.finish();
                                                  }

                                                  @Override
                                                  public void onFailure() {
                                                      ProgressDialog.dismiss();
                                                      Toast.makeText(loginActivity.this,"Something went wrong! Pls try again", Toast.LENGTH_SHORT).show();

                                                  }
                                              });

                                          }

                                          @Override
                                          public void onFailure() {
                                              ProgressDialog.dismiss();
                                              Toast.makeText(loginActivity.this,"Something went wrong! Pls try again", Toast.LENGTH_SHORT).show();
                                          }
                                      });
                                  }
                                  else
                                  {
                                      DbQuery.loadData(new MyCompleteListener() {
                                          @Override
                                          public void onSuccess() {
                                              ProgressDialog.dismiss();
                                              Intent intent = new Intent(loginActivity.this, MainActivity.class);
                                              startActivity(intent);
                                              loginActivity.this.finish();
                                          }

                                          @Override
                                          public void onFailure() {
                                              ProgressDialog.dismiss();
                                              Toast.makeText(loginActivity.this,"Something went wrong! Pls try again", Toast.LENGTH_SHORT).show();

                                          }
                                      });
                                  }

                              } else {
                                  ProgressDialog.dismiss();
                                  Toast.makeText(loginActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                              }

                          }
                      });
    }
}





//    private void googleSignIn() {
//Intent signInIntent = mGoogleSignInClient.getSignInIntent();
//startActivityForResult(signInIntent,RC_SIGN_IN);
//    }
//@Override
//    public  void  onActivityResult(int request, int resultCode ,Intent data) {
//        super.onActivityResult(resultCode,resultCode,data);
//        if(resultCode==RC_SIGN_IN){
//            Task<GoogleSignInAccount>task=GoogleSignIn.getSignedInAccountFromIntent(data);
//            try {
//                GoogleSignInAccount account = task.getResult(ApiException.class);
//                firebaseAuthWithGoogle(account.getIdToken());
//
//            }catch (ApiException e){
//                Toast.makeText(loginActivity.this,e.getMessage(),Toast.LENGTH_SHORT).show();
//
//            }
//        }
//}
//private void firebaseAuthWithGoogle(String idToken){
//        ProgressDialog.show();
//        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
//        mAuth.signInWithCredential(credential)
//                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<AuthResult> task) {
//                        if (task.isSuccessful()){
//                            Toast.makeText(loginActivity.this,"Google Sign In Success",Toast.LENGTH_SHORT).show();
//                            FirebaseUser user = mAuth.getCurrentUser();
//                            ProgressDialog.dismiss();
//                            Intent intent = new Intent(loginActivity.this,MainActivity.class);
//                            startActivity(intent);
//                            loginActivity.this.finish();
//                        }else {
//                            ProgressDialog.dismiss();
//                            Toast.makeText(loginActivity.this,task.getException().getMessage(),Toast.LENGTH_SHORT).show();
//                        }
//
//                    }
//


//GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
//                .requestIdToken(getString(R.string.default_web_client_id))
//                .requestEmail()
//                .build();
//        mGoogleSignInClient = GoogleSignIn.getClient(this,gso);


//    private void firebaseAuthWithGoogle(String idToken) {
//        ProgressDialog.show();
//        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
//        mAuth.signInWithCredential(credential)
//                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<AuthResult> task) {
//                        if (task.isSuccessful()) {
//                            Toast.makeText(loginActivity.this, "Google Sign In Success", Toast.LENGTH_SHORT).show();
//
//                            FirebaseUser user = mAuth.getCurrentUser();
//                            if (task.getResult().getAdditionalUserInfo().isNewUser())
//                            {
//
//                                DbQuery.createUserData(user.getEmail(), user.getDisplayName(), new MyCompleteListener() {
//                                    @Override
//                                    public void onSuccess() {
//                                        DbQuery.loadCategories(new MyCompleteListener() {
//                                            @Override
//                                            public void onSuccess() {
//                                                ProgressDialog.dismiss();
//                                                Intent intent = new Intent(loginActivity.this, MainActivity.class);
//                                                startActivity(intent);
//                                                loginActivity.this.finish();
//                                            }
//
//                                            @Override
//                                            public void onFailure() {
//                                                ProgressDialog.dismiss();
//                                                Toast.makeText(loginActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
//
//                                            }
//                                        });
//
//                                    }
//
//                                    @Override
//                                    public void onFailure() {
//                                        ProgressDialog.dismiss();
//                                        Toast.makeText(loginActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
//
//                                    }
//                                });
//                            }
//
//                            else
//                            {
//                                DbQuery.loadCategories(new MyCompleteListener() {
//                                    @Override
//                                    public void onSuccess() {
//                                        ProgressDialog.dismiss();
//                                        Intent intent = new Intent(loginActivity.this, MainActivity.class);
//                                        startActivity(intent);
//                                        loginActivity.this.finish();
//                                    }
//
//                                    @Override
//                                    public void onFailure() {
//                                        ProgressDialog.dismiss();
//                                        Toast.makeText(loginActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
//                                    }
//                                });
//                            }
//
//                        } else {
//                            ProgressDialog.dismiss();
//                            Toast.makeText(loginActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
//                        }
//                    }
//
//                });
